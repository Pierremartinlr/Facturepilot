/**
 * FacturePilot — Vercel Serverless Function
 * Route : POST /api/subscribe
 *
 * Rôle :
 *  1. Valide l'email reçu
 *  2. Envoie un email de bienvenue à l'utilisateur via Resend
 *  3. Envoie une notification interne (lead alert)
 *  4. Log le lead dans la console Vercel (visible dans le dashboard)
 *
 * Variables d'environnement requises sur Vercel :
 *  - RESEND_API_KEY   → votre clé API Resend (re_xxxxxxxxxxxx)
 *  - FROM_EMAIL       → email expéditeur vérifié sur Resend (ex: hello@facturepilot.io)
 *  - ADMIN_EMAIL      → votre email pour recevoir les notifications leads
 *
 * Installation :
 *  Ce fichier doit être placé dans /api/subscribe.js à la racine de votre projet Vercel.
 *  Aucune dépendance npm requise — utilise fetch natif (Node 18+).
 */

export default async function handler(req, res) {
  // ── CORS ──────────────────────────────────────────────────────────────
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // ── VALIDATION ────────────────────────────────────────────────────────
  const { email, source, timestamp } = req.body || {};

  if (!email || !email.includes('@') || !email.includes('.')) {
    return res.status(400).json({ error: 'Email invalide' });
  }

  const sanitizedEmail = email.toLowerCase().trim();
  const sanitizedSource = (source || 'direct').slice(0, 50);

  // ── CONFIG ────────────────────────────────────────────────────────────
  const RESEND_API_KEY = process.env.RESEND_API_KEY;
  const FROM_EMAIL     = process.env.FROM_EMAIL     || 'FacturePilot <hello@facturepilot.io>';
  const ADMIN_EMAIL    = process.env.ADMIN_EMAIL    || 'vous@facturepilot.io';

  if (!RESEND_API_KEY) {
    console.error('[FacturePilot] RESEND_API_KEY manquante — ajoutez-la dans les variables Vercel');
    // On répond quand même 200 pour ne pas bloquer l'UX
    return res.status(200).json({ success: true, warning: 'API key manquante' });
  }

  // ── HELPERS ───────────────────────────────────────────────────────────
  async function sendEmail({ to, subject, html }) {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: FROM_EMAIL,
        to,
        subject,
        html,
      }),
    });

    if (!response.ok) {
      const err = await response.text();
      throw new Error(`Resend error: ${response.status} — ${err}`);
    }

    return response.json();
  }

  // ── EMAIL DE BIENVENUE ────────────────────────────────────────────────
  const welcomeHTML = `
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Bienvenue dans FacturePilot !</title>
</head>
<body style="margin:0;padding:0;background:#f6f2ec;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f6f2ec;padding:40px 20px;">
    <tr>
      <td align="center">
        <table width="560" cellpadding="0" cellspacing="0" style="max-width:560px;width:100%;">

          <!-- HEADER -->
          <tr>
            <td style="background:#0e3d23;border-radius:16px 16px 0 0;padding:32px 36px;text-align:center;">
              <div style="font-family:'Georgia',serif;font-size:28px;font-weight:700;color:#fff;letter-spacing:-0.5px;">
                Facture<span style="color:#e8a020;">Pilot</span><span style="color:#e8a020;font-size:34px;line-height:0;vertical-align:middle;">.</span>
              </div>
              <div style="margin-top:16px;font-size:13px;color:rgba(255,255,255,0.5);letter-spacing:0.05em;text-transform:uppercase;font-weight:600;">
                7 jours gratuits · Accès complet activé
              </div>
            </td>
          </tr>

          <!-- CORPS -->
          <tr>
            <td style="background:#fffefb;padding:36px;border-left:1px solid #e0dbd2;border-right:1px solid #e0dbd2;">
              <h1 style="font-family:'Georgia',serif;font-size:26px;font-weight:700;color:#111110;margin:0 0 12px;line-height:1.2;">
                🎉 Bienvenue dans FacturePilot !
              </h1>
              <p style="font-size:15px;color:#7a7570;line-height:1.7;margin:0 0 24px;">
                Votre accès gratuit de <strong style="color:#111110;">7 jours</strong> est activé.
                Vous pouvez dès maintenant créer vos factures, devis et contrats,
                et activer les relances automatiques de paiement.
              </p>

              <!-- FEATURES -->
              <table width="100%" cellpadding="0" cellspacing="0" style="background:#e8f4ec;border-radius:12px;padding:0;margin-bottom:28px;">
                <tr>
                  <td style="padding:20px 22px;">
                    <div style="font-size:11px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:#1a5c36;margin-bottom:14px;">
                      Ce qui vous attend
                    </div>
                    ${[
                      ['⚡', 'Relances automatiques J+3, J+7, J+14, J+30', 'Votre USP — les relances travaillent à votre place'],
                      ['📄', 'Factures & devis illimités', 'Aperçu live, export PDF, TVA automatique'],
                      ['📱', 'Envoi WhatsApp, Email, SMS', 'Directement depuis l\'app, en 1 clic'],
                      ['🔐', 'Contrats IA en 60 secondes', 'Freelance, NDA, CGV générés instantanément'],
                    ].map(([icon, title, desc]) => `
                    <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:12px;">
                      <tr>
                        <td width="36" valign="top" style="font-size:18px;padding-top:2px;">${icon}</td>
                        <td>
                          <div style="font-size:14px;font-weight:700;color:#111110;margin-bottom:2px;">${title}</div>
                          <div style="font-size:12px;color:#7a7570;">${desc}</div>
                        </td>
                      </tr>
                    </table>`).join('')}
                  </td>
                </tr>
              </table>

              <!-- CTA PRINCIPAL -->
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center">
                    <a href="https://facturepilot.io" style="display:inline-block;background:#1a5c36;color:#fff;text-decoration:none;font-size:15px;font-weight:700;padding:16px 36px;border-radius:12px;letter-spacing:-0.2px;">
                      Accéder à FacturePilot →
                    </a>
                  </td>
                </tr>
              </table>

              <p style="font-size:13px;color:#ccc7be;text-align:center;margin:20px 0 0;">
                Après 7 jours : Pro à €19/mois · Annulez en 1 clic · Sans engagement
              </p>
            </td>
          </tr>

          <!-- FOOTER -->
          <tr>
            <td style="background:#f0ebe1;border:1px solid #e0dbd2;border-top:none;border-radius:0 0 16px 16px;padding:20px 36px;text-align:center;">
              <p style="font-size:11.5px;color:#7a7570;margin:0 0 6px;">
                Questions ? <a href="mailto:support@facturepilot.io" style="color:#1a5c36;font-weight:600;">support@facturepilot.io</a>
              </p>
              <p style="font-size:11px;color:#ccc7be;margin:0;">
                FacturePilot · Paris, France · RGPD · Données 100% privées<br>
                <a href="https://facturepilot.io#privacy" style="color:#ccc7be;">Se désinscrire</a>
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;

  // ── EMAIL NOTIFICATION ADMIN ──────────────────────────────────────────
  const adminHTML = `
<div style="font-family:monospace;background:#0e3d23;color:#7dd5a4;padding:24px;border-radius:12px;max-width:480px;">
  <div style="font-size:18px;font-weight:700;margin-bottom:16px;">🎯 Nouveau lead FacturePilot</div>
  <table style="width:100%;font-size:14px;">
    <tr><td style="color:rgba(255,255,255,.5);padding:4px 0;width:120px;">Email</td><td style="color:#fff;font-weight:700;">${sanitizedEmail}</td></tr>
    <tr><td style="color:rgba(255,255,255,.5);padding:4px 0;">Source</td><td style="color:#e8a020;">${sanitizedSource}</td></tr>
    <tr><td style="color:rgba(255,255,255,.5);padding:4px 0;">Date</td><td style="color:#fff;">${new Date().toLocaleString('fr-FR', { timeZone: 'Europe/Paris' })}</td></tr>
    <tr><td style="color:rgba(255,255,255,.5);padding:4px 0;">Timestamp</td><td style="color:rgba(255,255,255,.4);font-size:12px;">${timestamp || new Date().toISOString()}</td></tr>
  </table>
</div>`;

  // ── ENVOI ─────────────────────────────────────────────────────────────
  try {
    const results = await Promise.allSettled([
      // Email de bienvenue à l'utilisateur
      sendEmail({
        to: sanitizedEmail,
        subject: '🎉 Votre accès FacturePilot est activé — 7 jours gratuits',
        html: welcomeHTML,
      }),
      // Notification admin
      sendEmail({
        to: ADMIN_EMAIL,
        subject: `[Lead] ${sanitizedEmail} — FacturePilot (${sanitizedSource})`,
        html: adminHTML,
      }),
    ]);

    // Log détaillé dans Vercel
    console.log('[FacturePilot] Nouveau lead:', {
      email: sanitizedEmail,
      source: sanitizedSource,
      welcomeEmail: results[0].status,
      adminNotif: results[1].status,
      timestamp: new Date().toISOString(),
    });

    // Si l'email de bienvenue a échoué, on log l'erreur mais on répond 200
    if (results[0].status === 'rejected') {
      console.error('[FacturePilot] Échec email bienvenue:', results[0].reason);
    }

    return res.status(200).json({
      success: true,
      email: sanitizedEmail,
      welcomeSent: results[0].status === 'fulfilled',
    });

  } catch (error) {
    console.error('[FacturePilot] Erreur critique:', error);
    // On répond 200 pour ne jamais bloquer l'UX côté client
    return res.status(200).json({ success: true, warning: 'Email en attente' });
  }
}
