# FacturePilot — Guide de déploiement Vercel

## Structure des fichiers

```
facturepilot/
├── facturepilot.html     ← Landing page complète
├── api/
│   └── subscribe.js      ← Vercel Function (collecte email + Resend)
├── vercel.json           ← Configuration Vercel
└── README.md             ← Ce fichier
```

---

## Déploiement en 5 étapes

### Étape 1 — Créer le compte Resend (2 min)

1. Allez sur [resend.com](https://resend.com) et créez un compte gratuit
2. Dans **Domains**, ajoutez votre domaine `facturepilot.io`
3. Ajoutez les enregistrements DNS demandés (TXT + MX) chez votre registrar
4. Attendez la validation (5-30 min)
5. Dans **API Keys**, créez une clé → copiez-la (`re_xxxxxxxxxxxx`)

> ⚠️ Le plan gratuit Resend inclut 3 000 emails/mois et 100/jour — largement suffisant pour démarrer.

---

### Étape 2 — Préparer le projet (1 min)

Créez un dossier avec cette structure :

```bash
mkdir facturepilot
cd facturepilot
mkdir api
# Copiez les 3 fichiers livrés :
# facturepilot.html → ./facturepilot.html
# subscribe.js      → ./api/subscribe.js
# vercel.json       → ./vercel.json
```

---

### Étape 3 — Déployer sur Vercel (3 min)

**Option A — Via l'interface Vercel (recommandé)**

1. Allez sur [vercel.com](https://vercel.com) et connectez-vous
2. Cliquez **Add New → Project**
3. Importez depuis GitHub (recommandé) ou uploadez le dossier
4. Cliquez **Deploy** — c'est tout

**Option B — Via Vercel CLI**

```bash
npm i -g vercel
vercel login
vercel --prod
```

---

### Étape 4 — Variables d'environnement (2 min)

Dans votre projet Vercel → **Settings → Environment Variables**, ajoutez :

| Variable | Valeur | Exemple |
|----------|--------|---------|
| `RESEND_API_KEY` | Votre clé Resend | `re_xxxxxxxxxxxx` |
| `FROM_EMAIL` | Email expéditeur vérifié | `FacturePilot <hello@facturepilot.io>` |
| `ADMIN_EMAIL` | Votre email de notification | `vous@gmail.com` |

Après avoir ajouté les variables → cliquez **Redeploy**.

---

### Étape 5 — Brancher le domaine facturepilot.io (5 min)

1. Dans Vercel → **Settings → Domains**
2. Ajoutez `facturepilot.io` et `www.facturepilot.io`
3. Vercel vous donnera des enregistrements DNS (A + CNAME)
4. Ajoutez-les chez votre registrar
5. Propagation : 5 min à 2h

---

## Test de la fonction API

Une fois déployé, testez avec curl :

```bash
curl -X POST https://facturepilot.io/api/subscribe \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","source":"test"}'
```

Réponse attendue :
```json
{"success": true, "email": "test@example.com", "welcomeSent": true}
```

---

## Suivi des leads

Tous les leads sont visibles dans :

1. **Vercel Dashboard → Functions → Logs** — logs temps réel
2. **Resend Dashboard → Emails** — historique tous les emails envoyés
3. **Votre boîte email** (ADMIN_EMAIL) — notification à chaque nouveau lead

---

## En cas de problème

**Email non reçu par l'utilisateur :**
- Vérifiez que le domaine est bien validé sur Resend
- Vérifiez les logs Vercel pour les erreurs
- Vérifiez les spams

**Erreur 500 sur /api/subscribe :**
- Vérifiez que `RESEND_API_KEY` est bien définie dans les variables Vercel
- Vérifiez que `FROM_EMAIL` correspond à un domaine vérifié sur Resend

**Le site ne s'affiche pas :**
- Vérifiez que `facturepilot.html` est bien à la racine du projet
- Vérifiez le `vercel.json` (la route `"/(.*)"` doit pointer vers `/facturepilot.html`)

---

## Support

**support@facturepilot.io**
